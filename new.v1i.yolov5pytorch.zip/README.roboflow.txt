
new - v1 2021-09-12 6:55pm
==============================

This dataset was exported via roboflow.ai on September 12, 2021 at 10:55 AM GMT

It includes 100 images.
PerahuNelayan are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


