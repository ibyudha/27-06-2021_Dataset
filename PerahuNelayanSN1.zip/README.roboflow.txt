
PerahuNelayan - v1 PerahuNelayan 2021-09-12 8:41pm
==============================

This dataset was exported via roboflow.ai on September 12, 2021 at 12:41 PM GMT

It includes 100 images.
PerahuNelayan are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


